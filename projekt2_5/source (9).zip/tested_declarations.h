/*
 * Test dla zadania Projekt: Virtual FAT i długie nazwy plików (5,0)
 * Autor testowanej odpowiedzi: Mikołaj Rajczyk
 * Test wygenerowano automatycznie o 2021-12-19 22:07:43.261405
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta



        #include "file_reader.h"
   

#endif // _TESTED_DECLARATIONS_H_